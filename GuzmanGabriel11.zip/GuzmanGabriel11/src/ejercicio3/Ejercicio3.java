/*
 * Descripción: Prueva de los tipos de variables
 * Autor: Gabriel Guzmán
 * Fecha: 24/09/2025
 */

package ejercicio3;

public class Ejercicio3 {
	
	public static void main(String[] args) {
		
		int num1 = 0, num2 = 0;
		
		double val1, val2;
		
		String nombre = "Gabriel", apellidos = "Guzmán";
		
		System.out.println("Primer numero: " + num1 + " Segundo numero: " + num2);
		
		val1 = 28.34;
		val2 = 46.78;
		
		System.out.println("Primer decimal: " + val1 + " Segundo decimal: " + val2);

		System.out.println("Mi nombre es " + nombre + " y mi apellidos " + apellidos);

	}

}
