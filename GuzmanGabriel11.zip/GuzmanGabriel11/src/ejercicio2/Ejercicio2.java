/*
 * Descripción: Inprimer pon pantalla una secuencia de datos.
 * Autor: Gabriel Guzmán
 * Fecha: 23/09/2025
 */

package ejercicio2;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		System.out.println("Desarrollo de Aplicaciones WEB/Multiplataforma");
		
		System.out.println("1DAW /DAM");
		
		System.out.println("Módulos:");
		
		System.out.println("PRO");
		
		System.out.println("SIS");

	}

}
