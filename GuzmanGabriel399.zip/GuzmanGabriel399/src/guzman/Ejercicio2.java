/*
 * Descripción: .
 * Autor: Gabriel Guzmán
 * Fecha: 26/11/2025
 */

package guzman;

import java.util.Arrays;

public class Ejercicio2 { 
	
	public static void main(String[] args) {
		
		int [] [] ciberataquesAndalucia;
		
		final int CIUDADES = 8;
		final int DIAS = 16;
		
		ciberataquesAndalucia = new int [CIUDADES] [DIAS];
		
		System.out.println("-------------------------------------------");
		System.out.println("DATOS DE LA TABLA DE CIBERATAQUES ANDALUCIA");
		System.out.println("-------------------------------------------");
			
		System.out.println("----------------------------------------");
		System.out.println(Arrays.deepToString(ciberataquesAndalucia));
		
	}
	
}
