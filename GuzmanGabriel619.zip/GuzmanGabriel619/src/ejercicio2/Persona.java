/*
	Descripción:
	Autor: Gabriel Guzmán
	Fecha:  15/01/2026
	*/

package ejercicio2;

public class Persona {

	// ATRIBUTOS

	// Atributos de objeto

	public String dni;
	public String nombre;
	public String apellido;
	public int edad;

	// CONTRUCTOR

	// METODOS DE OBJETOS

	// METODOS DE CONTRUCTORES
}

