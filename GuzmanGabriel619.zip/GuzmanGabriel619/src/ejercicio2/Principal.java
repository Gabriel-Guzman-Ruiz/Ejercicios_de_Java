/*
 Descripción:
 Autor: Gabriel Guzmán
 Fecha:  15/01/2026
 */

package ejercicio2;

public class Principal {
	
public static void main(String[] args) {
		
		Persona persona1 = new Persona();
		Persona persona2 = new Persona();
	
		persona1.dni = "2356678f";
		persona1.nombre = "Gabriel";
		persona1.apellido = "Guzmán";
		persona1.edad = 21;
		
		persona2.dni = "8527037x";
		persona2.nombre = "Enrique";
		persona2.apellido = "Ruiz";
		persona2.edad = 12;
		
		System.out.printf("%s %s con DNI %s es mayor de edad (%d) %n",persona1.nombre, persona1.apellido , persona1.dni, persona1.edad);
		System.out.printf("%s %s con DNI %s no mayor de edad (%d)",persona2.nombre, persona2.apellido , persona2.dni, persona2.edad);
		
	}

}
