/*
Descripción:
Autor: Gabriel Guzmán
Fecha:  15/01/2026
*/

package ejercicio5;

import java.time.LocalDate;

public class Alumno {
	
	// ATRIBUTOS
	
	// Atributos contante de objeto

	public final static int NUMERO_MAXIMA_DE_ALUMNOS = 1000;
	
	// Atributos de clase	
	
	private static int numeroDeAlumnos = 0;	
	private static int numeroAlumnosTodosLosModulosAprobados = 0;
	
	// Atributos contante de objeto	
	
	private final int LIMITE_MODULOS_MATRICILA = 0;	
	
	// Atributos de objeto
	
	private String dni;
	private String nombre;
	private String apellidos;
	private LocalDate fechaNacimiento;
	private boolean tieneBeca;
	private double mediaModulosAprobados;
	
	// CONTRUCTOR

	// METODOS DE OBJETOS

	// METODOS DE CONTRUCTORES
	
}
