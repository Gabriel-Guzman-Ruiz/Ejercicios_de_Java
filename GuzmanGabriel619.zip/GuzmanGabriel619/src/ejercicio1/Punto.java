/*
Descripción:
Autor: Gabriel Guzmán
Fecha: 15/01/2026
*/

package ejercicio1;

public class Punto {

// ATRIBUTOS

// Atributos de objeto

public int x;
public int y;

// CONTRUCTOR

// METODOS DE OBJETOS

// METODOS DE CONTRUCTORES
}

