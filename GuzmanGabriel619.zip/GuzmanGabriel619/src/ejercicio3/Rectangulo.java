/*
 Descripción:
 Autor: Gabriel Guzmán
 Fecha:  15/01/2026
 */

package ejercicio3;

public class Rectangulo {
	
	// ATRIBUTOS

	// Atributos de objeto

	public int x1;
	public int y1;
	public int x2;
	public int y2;

	// CONTRUCTOR

	// METODOS DE OBJETOS

	// METODOS DE CONTRUCTORES
}
