/*
 Descripción:
 Autor: Gabriel Guzmán
 Fecha: 15/01/2026
 */

package ejercicio4;

public class Articulo {
	
	// ATRIBUTOS
	
	// Atributos contante de objeto	
	
	public final int IVA = 21;

	// Atributos de objeto

	public String nombre;
	public double precio;
	public int cuantosQuedan;

	// CONTRUCTOR

	// METODOS DE OBJETOS

	// METODOS DE CONTRUCTORES

}
