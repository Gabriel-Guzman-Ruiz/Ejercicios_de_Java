/*
 * Descripción: Mostramos variables antes establesidos
 * Autor: Gabriel Guzmán
 * Fecha: 30/09/2025
 */

package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num1 = 1;
		int num2 = 1;
		char char1 = 'a';
		char char2 = 'b';
		String cargo = "estudiante";
		String nombre = "Gabriel";
		
		System.out.println("-----------------------------------");
		System.out.println("Datos de variables:");
		System.out.println("-----------------------------------");	
		System.out.println(" Las Variables de la variable \"num1\" es: " + num1);
		System.out.println(" Las Variables de la variable \"num2\" es: " + num2);
		System.out.println("-----------------------------------");	
		System.out.println("Bienvenido, " + cargo + ", " + nombre);
	}

}
